import React from 'react';
import Tabledata from "./Tabledata.jsx"
const App = () => {
  return (
    <div className='container'>
      <h1 className='text-center'>
        Crud operation
      </h1>
      
      <Tabledata/>
    </div>
  );
};

export default App;